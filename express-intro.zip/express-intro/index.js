const express = require("express")

const app = express()

let books =[
    {
     name:"Sherlock"
    },
    {
     name:"Devil's Prada"
    },
    {
     name:"Twilight"
    },
    {
     name:"Avengers"
    },
]

app.get("/user",(req,res)=>{
   console.log("Bello")

   res.send("Hello people")
})

app.get("/books",(req,res)=>{
    res.send(books)
})


app.listen(4000, ()=>{
    console.log("Hello")
})